
let i=0;
let suma;

function promedio(elementos){
    let elementos = new Array;
    let longitud = elementos.length;

    do{
        suma= suma+elementos[i];
        i=i+1;
    }while (i<longitud)

    return(suma/longitud);
}
