let suma=0;
let oracion;

function concatenacion(oracion){
    let palabras= oracion.split(' ');
    return (palabras.join(''));
}










